package demo.spring;

public interface VerifyAddress {
	
	public boolean verifyAddress(Address address);

}
