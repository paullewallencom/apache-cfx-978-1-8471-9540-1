package demo.spring;

public interface VerifyCredit {
	
	public String GOOD_CREDIT ="GOOD";
	public String BAD_CREDIT ="BAD";
	public String verifyCredit(Customer customer);

}
