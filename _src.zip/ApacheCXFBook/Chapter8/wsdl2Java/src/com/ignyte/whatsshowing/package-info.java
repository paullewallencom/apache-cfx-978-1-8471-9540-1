@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.ignyte.com/whatsshowing", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ignyte.whatsshowing;
