@javax.xml.bind.annotation.XmlSchema(namespace = "http://order.demo/")
package demo.order;
