package demo.order;


public interface OrderProcess {
    String processOrder(Order order); 
}
